struct d_params {
	char group_name;
	int member_id;
};
